﻿using System;

public class Pupil
{
    public virtual void Study()
    {
        Console.WriteLine("Ученик учится.");
    }

    public virtual void Read()
    {
        Console.WriteLine("Ученик читает.");
    }

    public virtual void Write()
    {
        Console.WriteLine("Ученик пишет.");
    }

    public virtual void Relax()
    {
        Console.WriteLine("Ученик отдыхает.");
    }
}

public class ExcelentPupil : Pupil
{
    public override void Study()
    {
        Console.WriteLine("Отличник учится.");
    }

    public override void Read()
    {
        Console.WriteLine("Отличник читает.");
    }

    public override void Write()
    {
        Console.WriteLine("Отличник пишет.");
    }

    public override void Relax()
    {
        Console.WriteLine("Отличник отдыхает.");
    }
}

public class GoodPupil : Pupil
{
    public override void Study()
    {
        Console.WriteLine("Хороший ученик учится.");
    }

    public override void Read()
    {
        Console.WriteLine("Хороший ученик читает.");
    }

    public override void Write()
    {
        Console.WriteLine("Хороший ученик пишет.");
    }

    public override void Relax()
    {
        Console.WriteLine("Хороший ученик отдыхает.");
    }
}

public class BadPupil : Pupil
{
    public override void Study()
    {
        Console.WriteLine("Плохой ученик не любит учиться.");
    }

    public override void Read()
    {
        Console.WriteLine("Плохой ученик не хочет читать.");
    }

    public override void Write()
    {
        Console.WriteLine("Плохой ученик пишет с ошибками.");
    }

    public override void Relax()
    {
        Console.WriteLine("Плохой ученик просто отдыхает.");
    }
}

public class ClassRoom
{
    private Pupil[] pupils;

    public ClassRoom(params Pupil[] pupils)
    {
        this.pupils = new Pupil[4];
        for (int i = 0; i < pupils.Length && i < 4; i++)
        {
            this.pupils[i] = pupils[i];
        }

        for (int i = pupils.Length; i < 4; i++)
        {
            Random rnd = new Random();
            int pupilType = rnd.Next(1, 4);
            switch (pupilType)
            {
                case 1:
                    this.pupils[i] = new ExcelentPupil();
                    break;
                case 2:
                    this.pupils[i] = new GoodPupil();
                    break;
                case 3:
                    this.pupils[i] = new BadPupil();
                    break;
            }
        }
    }

    public void ShowPupilsActivities()
    {
        Console.WriteLine("Как ученики умеют учиться, читать, писать, отдыхать:");
        foreach (var pupil in pupils)
        {
            Console.WriteLine("--------------------");
            pupil.Study();
            pupil.Read();
            pupil.Write();
            pupil.Relax();
        }
    }
}

class Program
{
    static void Main()
    {
        ClassRoom classroom1 = new ClassRoom(new ExcelentPupil(), new GoodPupil(), new BadPupil());
        ClassRoom classroom2 = new ClassRoom(new ExcelentPupil(), new GoodPupil(), new BadPupil(), new GoodPupil());
        ClassRoom classroom3 = new ClassRoom();


        Console.WriteLine("Класс 1:");
        classroom1.ShowPupilsActivities();

        Console.WriteLine("Класс 2:");
        classroom2.ShowPupilsActivities();

        Console.WriteLine("Класс 3:");
        classroom3.ShowPupilsActivities();
    }
}
