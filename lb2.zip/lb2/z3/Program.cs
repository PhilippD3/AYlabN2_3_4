﻿using System;

class DocumentWorker
{
    public virtual void OpenDocument()
    {
        Console.WriteLine("Документ открыт");
    }

    public virtual void EditDocument()
    {
        Console.WriteLine("Редактирование документа доступно в версии Pro");
    }

    public virtual void SaveDocument()
    {
        Console.WriteLine("Сохранение документа доступно в версии Pro");
    }
}

class ProDocumentWorker : DocumentWorker
{
    public override void EditDocument()
    {
        Console.WriteLine("Документ отредактирован");
    }

    public override void SaveDocument()
    {
        Console.WriteLine("Документ сохранен в старом формате, сохранение в остальных форматах доступно в версии Expert");
    }
}

class ExpertDocumentWorker : ProDocumentWorker
{
    public override void SaveDocument()
    {
        Console.WriteLine("Документ сохранен в новом формате");
    }
}

class Program
{
    static void Main(string[] args)
    {
        string expertKey = "";
        Console.WriteLine("Введите номер ключа доступа Pro (если есть):");
        string proKey = Console.ReadLine();
        if (proKey == "")
        {
            Console.WriteLine("Введите номер ключа доступа Expert (если есть):");
            expertKey = Console.ReadLine();
        }
        

        DocumentWorker worker;

        if (proKey == "" && expertKey == "")
        {
            worker = new DocumentWorker();
        }
        else if (proKey == "111")
        {
            worker = new ProDocumentWorker();
        }
        else if (expertKey == "222")
        {
            worker = new ExpertDocumentWorker();
        }
        else
        {
            Console.WriteLine("Неверные ключи доступа.");
            return;
        }

        worker.OpenDocument();
        worker.EditDocument();
        worker.SaveDocument();

        Console.ReadKey();
    }
}
