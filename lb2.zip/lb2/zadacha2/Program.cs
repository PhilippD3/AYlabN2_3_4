﻿using System;

class Vehicle
{
    public int X;
    public int Y;
    public double Price;
    public double Speed;
    public int Year;

    public Vehicle(int x, int y, double price, double speed, int year)
    {
        X = x;
        Y = y;
        Price = price;
        Speed = speed;
        Year = year;
    }

    public override string ToString()
    {
        return $"Координаты: ({X}, {Y}), Цена: {Price}, Скорость: {Speed}, Год выпуска: {Year}";
    }
}

class Plane : Vehicle
{
    public double Altitude;
    public int Passengers;

    public Plane(int x, int y, double price, double speed, int year, double altitude, int passengers)
        : base(x, y, price, speed, year)
    {
        Altitude = altitude;
        Passengers = passengers;
    }

    public override string ToString()
    {
        return base.ToString() + $", Высота: {Altitude}, Количество пассажиров: {Passengers}";
    }
}

class Car : Vehicle
{
    public int Passengers;

    public Car(int x, int y, double price, double speed, int year, int passengers)
        : base(x, y, price, speed, year)
    {
        Passengers = passengers;
    }

    public override string ToString()
    {
        return base.ToString() + $", Количество пассажиров: {Passengers}";
    }
}

class Ship : Vehicle
{
    public int Passengers;
    public string Port;

    public Ship(int x, int y, double price, double speed, int year, int passengers, string port)
        : base(x, y, price, speed, year)
    {
        Passengers = passengers;
        Port = port;
    }

    public override string ToString()
    {
        return base.ToString() + $", Количество пассажиров: {Passengers}, Порт приписки: {Port}";
    }
}

class Program
{
    static void Main(string[] args)
    {
        Plane plane = new Plane(10, 20, 1000000, 900, 2020, 10000, 200);
        Car car = new Car(5, 15, 20000, 150, 2022, 5);
        Ship ship = new Ship(0, 0, 5000000, 30, 2018, 500, "New York");

        Console.WriteLine("Информация о самолете:");
        Console.WriteLine(plane);
        Console.WriteLine("\nИнформация об автомобиле:");
        Console.WriteLine(car);
        Console.WriteLine("\nИнформация о корабле:");
        Console.WriteLine(ship);

        Console.ReadKey();
    }
}