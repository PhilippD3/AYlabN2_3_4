﻿using System;

struct Vector
{
    public double x;
    public double y;
    public double z;

    public Vector(double x, double y, double z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    public static Vector operator +(Vector v1, Vector v2)
    {
        return new Vector(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z);
    }

    public static double operator *(Vector v1, Vector v2)
    {
        return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
    }

    public static Vector operator *(Vector v, double scalar)
    {
        return new Vector(v.x * scalar, v.y * scalar, v.z * scalar);
    }

    public static bool operator ==(Vector v1, Vector v2)
    {
        return v1.Length() == v2.Length();
    }

    public static bool operator !=(Vector v1, Vector v2)
    {
        return v1.Length() != v2.Length();
    }

    public static bool operator >(Vector v1, Vector v2)
    {
        return v1.Length() > v2.Length();
    }

    public static bool operator <(Vector v1, Vector v2)
    {
        return v1.Length() < v2.Length();
    }

    public static bool operator >=(Vector v1, Vector v2)
    {
        return v1.Length() >= v2.Length();
    }

    public static bool operator <=(Vector v1, Vector v2)
    {
        return v1.Length() <= v2.Length();
    }

    public double Length()
    {
        return Math.Sqrt(x * x + y * y + z * z);
    }

    public override bool Equals(object obj)
    {
        if (obj is Vector)
        {
            Vector other = (Vector)obj;
            return this.Length() == other.Length();
        }
        return false;
    }

    public override int GetHashCode()
    {
        return this.Length().GetHashCode();
    }
}

class Program
{
    static void Main(string[] args)
    {
        Vector v1 = new Vector(1, 2, 3);
        Vector v2 = new Vector(4, 5, 6);

        Vector v3 = v1 + v2;
        Console.WriteLine($"v1 + v2 = ({v3.x}, {v3.y}, {v3.z})");

        double scalarProduct = v1 * v2;
        Console.WriteLine($"v1 * v2 = {scalarProduct}");

        Vector v4 = v1 * 2.5;
        Console.WriteLine($"v1 * 2.5 = ({v4.x}, {v4.y}, {v4.z})");

        Console.WriteLine($"v1 == v2: {v1 == v2}");
        Console.WriteLine($"v1 != v2: {v1 != v2}");
        Console.WriteLine($"v1 > v2: {v1 > v2}");
        Console.WriteLine($"v1 < v2: {v1 < v2}");
        Console.WriteLine($"v1 >= v2: {v1 >= v2}");
        Console.WriteLine($"v1 <= v2: {v1 <= v2}");

        Console.ReadKey();
    }
}
