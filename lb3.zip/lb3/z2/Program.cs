﻿using System;
using System.Collections.Generic;

class Car : IEquatable<Car>
{
    public string Name;
    public string Engine;
    public int MaxSpeed;

    public Car(string name, string engine, int maxSpeed)
    {
        Name = name;
        Engine = engine;
        MaxSpeed = maxSpeed;
    }

    public override string ToString()
    {
        return Name;
    }

    public bool Equals(Car other)
    {
        if (other == null) return false;
        return Name == other.Name && Engine == other.Engine && MaxSpeed == other.MaxSpeed;
    }
}

class CarsCatalog
{
    private List<Car> cars = new List<Car>();

    public Car this[int index]
    {
        get
        {
            if (index >= 0 && index < cars.Count)
            {
                return cars[index];
            }
            else
            {
                throw new IndexOutOfRangeException();
            }
        }
        set
        {
            if (index >= 0 && index < cars.Count)
            {
                cars[index] = value;
            }
            else if (index == cars.Count)
            {
                cars.Add(value);
            }
            else
            {
                throw new IndexOutOfRangeException();
            }
        }
    }

    public string GetCarInfo(int index)
    {
        if (index >= 0 && index < cars.Count)
        {
            return $"{cars[index].Name} ({cars[index].Engine})";
        }
        else
        {
            return "Машины с таким индексом не существует.";
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        CarsCatalog catalog = new CarsCatalog();

        catalog[0] = new Car("Toyota Camry", "2.5L I4", 210);
        catalog[1] = new Car("Honda Civic", "1.8L I4", 180);
        catalog[2] = new Car("Ford Mustang", "5.0L V8", 250);

        Console.WriteLine(catalog[0]);
        Console.WriteLine(catalog[1]);
        Console.WriteLine(catalog[2]);

        Console.WriteLine(catalog.GetCarInfo(0));
        Console.WriteLine(catalog.GetCarInfo(1));
        Console.WriteLine(catalog.GetCarInfo(2));

        Car car1 = new Car("Toyota Camry", "2.5L I4", 210);
        Car car2 = new Car("Toyota Camry", "2.5L I4", 210);
        Car car3 = new Car("Honda Civic", "1.8L I4", 180);

        Console.WriteLine($"car1 == car2: {car1.Equals(car2)}");
        Console.WriteLine($"car1 == car3: {car1.Equals(car3)}");

        Console.ReadKey();
    }
}
