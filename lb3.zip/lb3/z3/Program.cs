﻿using System;

public class Currency
{
    public decimal Value;

    public Currency(decimal value)
    {
        Value = value;
    }
}

public class CurrencyUSD : Currency
{
    public CurrencyUSD(decimal value) : base(value) { }

    public static implicit operator CurrencyEUR(CurrencyUSD usd)
    {
        decimal exchangeRate = 0.85m;
        return new CurrencyEUR(usd.Value * exchangeRate);
    }

    public static implicit operator CurrencyRUB(CurrencyUSD usd)
    {
        decimal exchangeRate = 75.0m;
        return new CurrencyRUB(usd.Value * exchangeRate);
    }
}

public class CurrencyEUR : Currency
{
    public CurrencyEUR(decimal value) : base(value) { }

    public static implicit operator CurrencyUSD(CurrencyEUR eur)
    {
        decimal exchangeRate = 1.18m;
        return new CurrencyUSD(eur.Value * exchangeRate);
    }

    public static implicit operator CurrencyRUB(CurrencyEUR eur)
    {
        decimal exchangeRate = 88.0m;
        return new CurrencyRUB(eur.Value * exchangeRate);
    }
}

public class CurrencyRUB : Currency
{
    public CurrencyRUB(decimal value) : base(value) { }

    public static implicit operator CurrencyUSD(CurrencyRUB rub)
    {
        decimal exchangeRate = 0.013m;
        return new CurrencyUSD(rub.Value * exchangeRate);
    }

    public static implicit operator CurrencyEUR(CurrencyRUB rub)
    {
        decimal exchangeRate = 0.011m;
        return new CurrencyEUR(rub.Value * exchangeRate);
    }
}

class Program
{
    static void Main(string[] args)
    {
        CurrencyUSD usd = new CurrencyUSD(100);
        CurrencyEUR eur = usd;
        CurrencyRUB rub = usd;

        Console.WriteLine($"100 USD in EUR: {eur.Value}");
        Console.WriteLine($"100 USD in RUB: {rub.Value}");

        CurrencyUSD convertedBackUsd = (CurrencyUSD)eur;
        Console.WriteLine($"Converted back EUR to USD: {convertedBackUsd.Value}");
    }
}
