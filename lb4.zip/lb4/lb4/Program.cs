﻿using System;

class MyMatrix
{
    private int[,] matrix;
    private int rows;
    private int cols;

    public MyMatrix(int rows, int cols, int min, int max)
    {
        this.rows = rows;
        this.cols = cols;
        matrix = new int[rows, cols];

        Random random = new Random();
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                matrix[i, j] = random.Next(min, max + 1);
            }
        }
    }

    public int this[int row, int col]
    {
        get
        {
            if (row >= 0 && row < rows && col >= 0 && col < cols)
            {
                return matrix[row, col];
            }
            else
            {
                throw new IndexOutOfRangeException();
            }
        }
        set
        {
            if (row >= 0 && row < rows && col >= 0 && col < cols)
            {
                matrix[row, col] = value;
            }
            else
            {
                throw new IndexOutOfRangeException();
            }
        }
    }

    public static MyMatrix operator +(MyMatrix m1, MyMatrix m2)
    {
        if (m1.rows != m2.rows || m1.cols != m2.cols)
        {
            throw new ArgumentException("Матрицы должны иметь одинаковые размеры");
        }

        MyMatrix result = new MyMatrix(m1.rows, m1.cols, 0, 0);
        for (int i = 0; i < m1.rows; i++)
        {
            for (int j = 0; j < m1.cols; j++)
            {
                result[i, j] = m1[i, j] + m2[i, j];
            }
        }
        return result;
    }

    public static MyMatrix operator -(MyMatrix m1, MyMatrix m2)
    {
        if (m1.rows != m2.rows || m1.cols != m2.cols)
        {
            throw new ArgumentException("Матрицы должны иметь одинаковые размеры");
        }

        MyMatrix result = new MyMatrix(m1.rows, m1.cols, 0, 0);
        for (int i = 0; i < m1.rows; i++)
        {
            for (int j = 0; j < m1.cols; j++)
            {
                result[i, j] = m1[i, j] - m2[i, j];
            }
        }
        return result;
    }

    public static MyMatrix operator *(MyMatrix m1, MyMatrix m2)
    {
        if (m1.cols != m2.rows)
        {
            throw new ArgumentException("Количество столбцов первой матрицы должно быть равно количеству строк второй матрицы");
        }

        MyMatrix result = new MyMatrix(m1.rows, m2.cols, 0, 0);
        for (int i = 0; i < m1.rows; i++)
        {
            for (int j = 0; j < m2.cols; j++)
            {
                for (int k = 0; k < m1.cols; k++)
                {
                    result[i, j] += m1[i, k] * m2[k, j];
                }
            }
        }
        return result;
    }

    public static MyMatrix operator *(MyMatrix m, int scalar)
    {
        MyMatrix result = new MyMatrix(m.rows, m.cols, 0, 0);
        for (int i = 0; i < m.rows; i++)
        {
            for (int j = 0; j < m.cols; j++)
            {
                result[i, j] = m[i, j] * scalar;
            }
        }
        return result;
    }

    public static MyMatrix operator /(MyMatrix m, int scalar)
    {
        if (scalar == 0)
        {
            throw new DivideByZeroException();
        }

        MyMatrix result = new MyMatrix(m.rows, m.cols, 0, 0);
        for (int i = 0; i < m.rows; i++)
        {
            for (int j = 0; j < m.cols; j++)
            {
                result[i, j] = m[i, j] / scalar;
            }
        }
        return result;
    }

    public void PrintMatrix()
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                Console.Write(matrix[i, j] + " ");
            }
            Console.WriteLine();
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите минимальное значение для случайных чисел:");
        int min = int.Parse(Console.ReadLine());
        Console.WriteLine("Введите максимальное значение для случайных чисел:");
        int max = int.Parse(Console.ReadLine());

        Console.WriteLine("Введите количество строк:");
        int rows = int.Parse(Console.ReadLine());
        Console.WriteLine("Введите количество столбцов:");
        int cols = int.Parse(Console.ReadLine());

        MyMatrix m1 = new MyMatrix(rows, cols, min, max);
        MyMatrix m2 = new MyMatrix(rows, cols, min, max);

        Console.WriteLine("Матрица m1:");
        m1.PrintMatrix();
        Console.WriteLine("Матрица m2:");
        m2.PrintMatrix();

        MyMatrix m3 = m1 + m2;
        Console.WriteLine("m1 + m2:");
        m3.PrintMatrix();

        MyMatrix m4 = m1 - m2;
        Console.WriteLine("m1 - m2:");
        m4.PrintMatrix();

        MyMatrix m5 = m1 * m2;
        Console.WriteLine("m1 * m2:");
        m5.PrintMatrix();

        MyMatrix m6 = m1 * 3;
        Console.WriteLine("m1 * 3:");
        m6.PrintMatrix();

        MyMatrix m7 = m1 / 2;
        Console.WriteLine("m1 / 2:");
        m7.PrintMatrix();

        Console.ReadKey();
    }
}