﻿//using System;
//using System.Collections.Generic;

//class Car
//{
//    public string Name { set; get; }
//    public int ProductionYear;
//    public int MaxSpeed;
//    public Car(string name, int productionYear, int maxSpeed)
//    {
//        Name = name;
//        ProductionYear = productionYear;
//        MaxSpeed = maxSpeed;
//    }
//}

//class CarComparer : IComparer<Car>
//{
//    private int sortField;

//    public CarComparer(int sortField)
//    {
//        this.sortField = sortField;
//    }

//    public int Compare(Car car1, Car car2)
//    {
//        switch (sortField)
//        {
//            case 0:
//                return string.Compare(car1.Name, car2.Name);
//            case 1:
//                return car1.ProductionYear.CompareTo(car2.ProductionYear);
//            case 2:
//                return car1.MaxSpeed.CompareTo(car2.MaxSpeed);
//            default:
//                throw new ArgumentException("Неверный параметр сортировки.");
//        }
//    }
//}

//class Program
//{
//    static void Main(string[] args)
//    {
//        Car[] cars = new Car[]
//        {
//            new Car("Ford Mustang", 2023, 250),
//            new Car("Toyota Camry", 2022, 210),
//            new Car("Honda Civic", 2021, 180),
//            new Car("BMW M3", 2022, 280),
//            new Car("Audi A4", 2020, 230)
//        };

//        Array.Sort(cars, new CarComparer(0));
//        Console.WriteLine("Сортировка по имени:");
//        PrintCars(cars);

//        Array.Sort(cars, new CarComparer(1));
//        Console.WriteLine("Сортировка по году выпуска:");
//        PrintCars(cars);

//        Array.Sort(cars, new CarComparer(2));
//        Console.WriteLine("Сортировка по максимальной скорости:");
//        PrintCars(cars);

//        Console.ReadKey();
//    }

//    static void PrintCars(Car[] cars)
//    {
//        foreach (Car car in cars)
//        {
//            Console.WriteLine($"{car.Name} ({car.ProductionYear}) - {car.MaxSpeed} км/ч");
//        }
//        Console.WriteLine();
//    }
//}

Person p = new Person() { Firstname = 12, Age = -12 };
Console.WriteLine(p.Age);
class Person
{
    private int lastName;
    private int age;
    public int Age 
    {
        get
        {
            return age;
        }
        set
        {
            if(value <=0)
            {
                throw new ArgumentException("Age should be greater that zero");
            }
            age = value;
        }
    }
    public int Lastname => lastName;
    public int Firstname { get; set; }
}
