﻿using System;
using System.Collections.Generic;

class Car
{
    public string Name;
    public int ProductionYear;
    public int MaxSpeed;

    public Car(string name, int productionYear, int maxSpeed)
    {
        Name = name;
        ProductionYear = productionYear;
        MaxSpeed = maxSpeed;
    }
}

class CarCatalog
{
    private Car[] cars;

    public CarCatalog(Car[] cars)
    {
        this.cars = cars;
    }

    public IEnumerable<Car> IterateForward()
    {
        for (int i = 0; i < cars.Length; i++)
        {
            yield return cars[i];
        }
    }

    public IEnumerable<Car> IterateBackward()
    {
        for (int i = cars.Length - 1; i >= 0; i--)
        {
            yield return cars[i];
        }
    }

    public IEnumerable<Car> IterateByYear(int year)
    {
        foreach (Car car in cars)
        {
            if (car.ProductionYear == year)
            {
                yield return car;
            }
        }
    }

    public IEnumerable<Car> IterateBySpeed(int speed)
    {
        foreach (Car car in cars)
        {
            if (car.MaxSpeed >= speed)
            {
                yield return car;
            }
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Car[] cars = new Car[]
        {
            new Car("Ford Mustang", 2023, 250),
            new Car("Toyota Camry", 2022, 210),
            new Car("Honda Civic", 2021, 180),
            new Car("BMW M3", 2022, 280),
            new Car("Audi A4", 2020, 230)
        };

        CarCatalog carCatalog = new CarCatalog(cars);

        Console.WriteLine("Прямой проход:");
        foreach (Car car in carCatalog.IterateForward())
        {
            Console.WriteLine($"{car.Name} ({car.ProductionYear}) - {car.MaxSpeed} км/ч");
        }
        Console.WriteLine();

        Console.WriteLine("Обратный проход:");
        foreach (Car car in carCatalog.IterateBackward())
        {
            Console.WriteLine($"{car.Name} ({car.ProductionYear}) - {car.MaxSpeed} км/ч");
        }
        Console.WriteLine();

        Console.WriteLine("Проход по году выпуска 2022:");
        foreach (Car car in carCatalog.IterateByYear(2022))
        {
            Console.WriteLine($"{car.Name} ({car.ProductionYear}) - {car.MaxSpeed} км/ч");
        }
        Console.WriteLine();

        Console.WriteLine("Проход по максимальной скорости 230 км/ч:");
        foreach (Car car in carCatalog.IterateBySpeed(230))
        {
            Console.WriteLine($"{car.Name} ({car.ProductionYear}) - {car.MaxSpeed} км/ч");
        }
        Console.WriteLine();

        Console.ReadKey();
    }
}